C1 Grammatik — Anki-Decks (Bände 1–9)
=====================================
Import in Anki:
1. Datei → Importieren → CSV-Datei wählen
2. Feldtrenner: Semikolon (;)
3. Notiztyp: "Einfach" (Basic) — Feld 1 = Vorderseite, Feld 2 = Rückseite
4. Pro Band ein eigenes Deck anlegen (z.B. "C1 · Band 3 Verben")

Empfehlung für Kursteilnehmer: täglich 10 Minuten, alle Decks gemischt
(Anki-Option "Unterdecks mischen") — das entspricht dem
Mischtraining-Prinzip aus Band 10.
